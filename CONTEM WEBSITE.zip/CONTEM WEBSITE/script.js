const basketList = document.querySelector("#basketList");
const basketTotal = document.querySelector("#basketTotal");
const addButtons = document.querySelectorAll(".add-button");
const groupButtons = document.querySelectorAll(".group-button");
const categoryButtons = document.querySelectorAll(".category-button");
const categoryFilterGroups = document.querySelectorAll(".category-filters");
const productCards = document.querySelectorAll(".product-card");
const checkoutButton = document.querySelector(".checkout-button");
const deliveryFee = 80;
const basket = new Map();
let activeGroup = "fruits";
let activeCategory = "all";

function formatPeso(amount) {
  return `PHP ${amount.toLocaleString("en-US")}`;
}

function renderBasket() {
  basketList.innerHTML = "";

  if (basket.size === 0) {
    basketList.innerHTML = '<p class="empty-state">Add products to estimate an order.</p>';
    basketTotal.textContent = "PHP 0";
    return;
  }

  let subtotal = 0;

  basket.forEach((item) => {
    subtotal += item.price * item.quantity;

    const row = document.createElement("div");
    row.className = "basket-item";
    row.innerHTML = `
      <span>${item.quantity}x ${item.name}</span>
      <strong>${formatPeso(item.price * item.quantity)}</strong>
    `;
    basketList.append(row);
  });

  basketTotal.textContent = formatPeso(subtotal + deliveryFee);
}

addButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const card = button.closest(".product-card");
    const name = card.dataset.name;
    const price = Number(card.dataset.price);
    const existing = basket.get(name);

    basket.set(name, {
      name,
      price,
      quantity: existing ? existing.quantity + 1 : 1,
    });

    button.textContent = "Added";
    window.setTimeout(() => {
      button.textContent = "Add";
    }, 900);

    renderBasket();
  });
});

function updateProducts() {
  productCards.forEach((card) => {
    const matchesGroup = card.dataset.group === activeGroup;
    const matchesCategory = activeCategory === "all" || card.dataset.category === activeCategory;

    card.hidden = !matchesGroup || !matchesCategory;
  });
}

groupButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeGroup = button.dataset.group;
    activeCategory = "all";

    groupButtons.forEach((groupButton) => {
      groupButton.classList.toggle("active", groupButton === button);
    });

    categoryFilterGroups.forEach((filterGroup) => {
      const isActiveGroup = filterGroup.dataset.filterGroup === activeGroup;

      filterGroup.classList.toggle("active", isActiveGroup);
      filterGroup.querySelectorAll(".category-button").forEach((categoryButton, index) => {
        categoryButton.classList.toggle("active", isActiveGroup && index === 0);
      });
    });

    updateProducts();
  });
});

categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.category;

    button.closest(".category-filters").querySelectorAll(".category-button").forEach((categoryButton) => {
      categoryButton.classList.toggle("active", categoryButton === button);
    });

    updateProducts();
  });
});

checkoutButton.addEventListener("click", () => {
  if (basket.size === 0) {
    checkoutButton.textContent = "Add Items First";
  } else {
    checkoutButton.textContent = "Delivery Slot Reserved";
  }

  window.setTimeout(() => {
    checkoutButton.textContent = "Reserve Delivery Slot";
  }, 1400);
});
